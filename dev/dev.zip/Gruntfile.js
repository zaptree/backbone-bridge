module.exports = function(grunt) {
	grunt.initConfig({
		//pkg: grunt.file.readJSON('package.json'),
		read_css_import:{
			'file':'testgrunt/css/_loader.css'
		},
		read_lab_config:{
			'file':'lab.js'
		},

		cssmin: {
			compress: {
				files: {}//this will be set from the custom read_css_import
			}
		},
		uglify: {
			options: {
				mangle: false
			},
			core: {
				files: {}//this will be set from the custom read_lab_config
			}
		}
	});
	/**
	 * the cssmin does not take care of imports... stupid, they are currently adding it I believe so check.
	 * this function reads our _loader.css which only has all the css files imports and we use that to create
	 * our list of css files dynamically.
	 */
	grunt.registerTask('read_css_import',function(){
		var config = grunt.config.data,
			options = config.read_css_import,
			basePath = options.file.substring(0,options.file.lastIndexOf("/")+1),
			cssFiles=[];
		css = grunt.file.read(options.file);
		var matches = css.match(/@import.+?;/g);
		matches.forEach(function(cssImport){
			var match = cssImport.match(/@import[ ]+['"](.+?)['"];/);
			cssFiles.push(basePath+match[1]);
		});
		config.cssmin.compress.files['dist/styles.css'] = cssFiles;

	});
	grunt.registerTask('read_lab_config',function(){
		var config = grunt.config.data,
			options = config.read_lab_config,
			basePath = options.file.substring(0,options.file.lastIndexOf("/")+1),
			jsFiles=[];
		labjs = grunt.file.read(options.file);
		var matches = labjs.match(/script\(['"](.+?)['"]\)/g);
		matches.forEach(function(jsFile){
			var match = jsFile.match(/script\(['"](.+?)['"]\)/)

			jsFiles.push(basePath+match[1]);
		});
		grunt.config.data.uglify.core.files['dist/app.js'] = jsFiles;

	});


	// Load the plugin that provides the "uglify" task.
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-uglify');

	// Default task(s).
	grunt.registerTask('release', ['read_css_import','read_lab_config','uglify:core','cssmin']);
};